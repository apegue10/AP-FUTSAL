# AP FUTSAL para Android — proyecto inicial

Este proyecto contiene la versión HTML actual de AP FUTSAL dentro de una aplicación Android basada en WebView.

## Qué incluye
- Nombre de aplicación: AP FUTSAL.
- Pantalla completa sin barra de título.
- JavaScript y almacenamiento local habilitados para que funcionen la interfaz y `localStorage`.
- HTML empaquetado en `app/src/main/assets/index.html`; la interfaz principal no necesita abrir una web externa.

## Estado importante
Este es el **proyecto fuente inicial**, no un APK ya compilado. En el entorno en el que se preparó no hay Android SDK/Gradle instalado, por lo que no se ha podido generar ni probar un APK instalable en la tablet.

Antes de usarlo en partidos reales, hay que probar en Android la persistencia de datos, los botones de exportación y especialmente la impresión/creación de PDF. El comportamiento de ventanas emergentes y la impresión en WebView puede requerir integración nativa adicional.

## Compilar
Abrir la carpeta completa en Android Studio, instalar el SDK de Android 35 cuando lo solicite, sincronizar Gradle y ejecutar en un dispositivo o generar APK desde Build > Build APK(s).
